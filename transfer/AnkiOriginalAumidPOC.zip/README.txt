Anki Original AUMID Taskbar POC
===============================

Purpose: detect the AUMID used by the REAL running Anki window / original Start Menu shortcut, restart this POC with that exact AUMID before UI creation, then test the production taskbar pin matrix without inventing Anki.ZikaronHaLimud.Desktop.

How to test
-----------
1. Run the real Anki and leave its main window open.
2. Run AnkiOriginalAumidPOC.exe as a normal user.
3. Click: 1. Detect original AUMID + restart.
   The POC scans the running Anki top-level window and the original Start Menu shortcut.
   It prefers the running-window AUMID because that is the grouping identity Windows is actually using.
4. After the POC restarts, confirm the second status line shows the detected AUMID.
5. Click Prepare shortcut.
6. Unpin/reset before each test, then use the button matching the OS:
   - Windows 10 -> SysPin/PTTB
   - Windows 11 old where LAF required -> IPinnedList3
   - Windows 11 new where LAF is not required -> Modern TaskbarManager
   Or click AUTO production matrix.
7. Close the POC and launch Anki from the new pinned icon. Correct result: the already pinned icon becomes active; Windows must NOT create a second Anki taskbar icon.

If Detect says no explicit AUMID was found, make sure the real Anki window is open and retry.

The SysPin/PTTB helper is embedded into the EXE at build time from:
https://github.com/0x546F6D/pttb_-_Pin_To_TaskBar (Unlicense).
